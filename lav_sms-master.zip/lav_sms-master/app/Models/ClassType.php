<?php

namespace App\Models;

use Eloquent;

class ClassType extends Eloquent
{
    //
}
